<?php


require get_template_directory() . '/functions/theme-support.php';
require get_template_directory() . '/functions/sidebar.php';
require get_template_directory() . '/functions/enqueue.php';


/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function dreamui_content_width()
{
	$GLOBALS['content_width'] = apply_filters('dreamui_content_width', 640);
}
add_action('after_setup_theme', 'dreamui_content_width', 0);

/**
 * Implement TGM Plugin activator.
 */
require_once get_template_directory() . '/functions/inc/tgm.php';
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/functions/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/functions/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/functions/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/functions/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/functions/inc/jetpack.php';
}

function dreamui_example_excerpt_length($length)
{
	return 0;
}
add_filter('excerpt_length', 'dreamui_example_excerpt_length');

function dreamui_theme_excerpt_more($more)
{
	return '<a class="read_more" href="' . get_permalink() . '">Read More <i class="fa-solid fa-arrow-right"></i></a>';
}
add_filter('excerpt_more', 'dreamui_theme_excerpt_more');
