<?php
defined('ABSPATH') || exit;
?>
<?php
if (is_single()) {
	$dreamui_post_colums = 'col-12';
} elseif (!is_active_sidebar('sidebar-1')) {
	$dreamui_post_colums = 'col-sm-6 col-md-4 col-lg-3';
} else {
	$dreamui_post_colums = 'col-sm-6 col-md-4';
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(array($dreamui_post_colums, 'single-post p-3')); ?>>
	<header class="entry-header">
		<?php
		if (is_singular()) :
			the_title('<h1 class="entry-title">', '</h1>');
		else :
			the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
		endif;

		if ('post' === get_post_type()) :
		?>
			<div class="entry-meta">
				<?php
				dreamui_posted_by();
				dreamui_entry_footer();
				dreamui_posted_on();
				?>
			</div>
		<?php endif; ?>
	</header>

	<?php dreamui_post_thumbnail(); ?>

	<div class="entry-content">
		<?php
		if (is_single()) {
			the_content(
				sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__('Continue reading<span class="screen-reader-text"> "%s"</span>', 'dreamui'),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post(get_the_title())
				)
			);
		} else {
			the_excerpt(
				sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__('Continue reading<span class="screen-reader-text"> "%s"</span>', 'dreamui'),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post(get_the_title())
				)
			);
		}
		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__('Pages:', 'dreamui'),
				'after'  => '</div>',
			)
		);
		?>
	</div>

	<footer class="entry-footer">
		<?php dreamui_entry_footer(); ?>
	</footer>
</article><!-- #post-<?php the_ID(); ?> -->