<?php
defined('ABSPATH') || exit;

get_header();
?>

<?php
if (is_active_sidebar('sidebar-1')) {
	$dreamui_is_sidebar_colums = 'col-md-9';
} else {
	$dreamui_is_sidebar_colums = 'col-12';
}
?>
<div class="container mt-3">
	<div class="row">
		<div class="<?php echo $dreamui_is_sidebar_colums; ?>">
			<main id="primary" class="site-main d-flex flex-wrap justify-content-around">

				<?php
				if (have_posts()) :

					if (is_home() && ! is_front_page()) :
				?>
						<header>
							<h1 class="page-title screen-reader-text"><?php //single_post_title(); 
																		?></h1>
						</header>
				<?php
					endif;

					while (have_posts()) :
						the_post();
						get_template_part('template-parts/content', get_post_type());
					endwhile;
				else :
					get_template_part('template-parts/content', 'none');
				endif;
				?>

			</main>
			<div class="post-pagination m-5 d-flex justify-content-center">
				<?php
				the_posts_pagination();
				?>
			</div>
		</div>
		<div class="col-md-3">
			<?php
			get_sidebar();
			?>
		</div>
	</div>
</div>

<?php
get_footer();
